package Clases;

abstract interface Interfaz {

    public void crear();

    public void mostrar();

    public void actualizar();

    public void eliminar();

}
